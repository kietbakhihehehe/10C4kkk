-- Chạy trong Supabase > SQL Editor
create table if not exists public.wishes (
  id bigint generated always as identity primary key,
  sender_name text not null check (char_length(btrim(sender_name)) between 1 and 60),
  class_name text check (class_name is null or char_length(class_name) <= 60),
  message text not null check (char_length(btrim(message)) between 1 and 600),
  created_at timestamptz not null default now()
);
alter table public.wishes enable row level security;
create policy "Ai cũng xem được" on public.wishes for select using (true);
create policy "Ai cũng gửi được" on public.wishes for insert with check (true);
-- Không có policy update/delete: người dùng không sửa/xóa được lời chúc.

-- Chống spam: tối đa 5 lời chúc / 1 phút trên toàn bảng
create or replace function public.limit_wish_rate() returns trigger language plpgsql as $$
begin
  if (select count(*) from public.wishes where created_at > now() - interval '1 minute') >= 5 then
    raise exception 'Quá nhiều lời chúc, vui lòng thử lại sau ít phút.';
  end if;
  return new;
end $$;
drop trigger if exists wishes_rate on public.wishes;
create trigger wishes_rate before insert on public.wishes for each row execute function public.limit_wish_rate();
