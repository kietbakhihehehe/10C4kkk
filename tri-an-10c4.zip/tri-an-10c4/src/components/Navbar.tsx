import { useEffect, useState } from 'react'
import { Menu, X } from 'lucide-react'
import { LOGOS } from '../data'

const ITEMS = [['home', 'TRANG CHỦ'], ['gallery', 'HÌNH ẢNH 10C4'], ['wishes', 'GỬI LỜI CHÚC']]

export default function Navbar() {
  const [active, setActive] = useState('home')
  const [open, setOpen] = useState(false)
  useEffect(() => {
    const io = new IntersectionObserver(es => es.forEach(e => e.isIntersecting && setActive(e.target.id)), { rootMargin: '-45% 0px -50% 0px' })
    ITEMS.forEach(([id]) => { const el = document.getElementById(id); if (el) io.observe(el) })
    return () => io.disconnect()
  }, [])
  return (
    <header className="fixed top-0 inset-x-0 z-50 glass !border-x-0 !border-t-0" style={{ paddingTop: 'env(safe-area-inset-top)' }}>
      <nav className="max-w-6xl mx-auto flex items-center justify-between px-4 h-14">
        <a href="#home" className="flex items-center gap-2 font-display font-bold text-gold">
          <img src={LOGOS.school} alt="" className="h-8 w-8 object-contain" onError={e => (e.currentTarget.style.display = 'none')} />10C4
        </a>
        <ul className="hidden md:flex gap-8 font-ui text-xs tracking-widest">
          {ITEMS.map(([id, label]) => (
            <li key={id}><a href={`#${id}`} className={active === id ? 'text-gold border-b border-gold pb-1' : 'text-cream/80 hover:text-gold'}>{label}</a></li>
          ))}
        </ul>
        <button className="md:hidden p-2" aria-label="Menu" onClick={() => setOpen(o => !o)}>{open ? <X /> : <Menu />}</button>
      </nav>
      {open && (
        <ul className="md:hidden px-4 pb-4 grid gap-3 font-ui text-sm tracking-widest">
          {ITEMS.map(([id, label]) => <li key={id}><a href={`#${id}`} onClick={() => setOpen(false)} className={active === id ? 'text-gold' : ''}>{label}</a></li>)}
        </ul>
      )}
    </header>
  )
}
