import { useEffect, useRef } from 'react'
import { ChevronDown } from 'lucide-react'
import { LOGOS, PHOTOS } from '../data'

const go = (id: string) => document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' })
const dust = Array.from({ length: 18 }, (_, i) => ({ l: (i * 37) % 100, s: 3 + (i % 4) * 2, d: 9 + (i % 6) * 2, de: -(i * 1.3) }))

export default function Hero() {
  const bg = useRef<HTMLDivElement>(null)
  useEffect(() => {
    const reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches
    if (reduce) return
    const on = () => { if (bg.current) bg.current.style.transform = `translateY(${Math.min(window.scrollY, 800) * 0.25}px)` }
    window.addEventListener('scroll', on, { passive: true }); return () => window.removeEventListener('scroll', on)
  }, [])
  const d = (n: number) => ({ animationDelay: `${n}s` })
  return (
    <section id="home" className="relative h-[100svh] w-full overflow-hidden bg-moss text-center">
      <div ref={bg} className="absolute inset-0 will-change-transform">
        <div className="absolute inset-0 kenburns bg-cover" style={{ backgroundImage: `url(${PHOTOS[0].src})`, backgroundPosition: 'center 35%' }} />
      </div>
      <div className="absolute inset-0 bg-gradient-to-b from-ink/80 via-moss/45 to-ink/90" />
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_50%_40%,rgba(214,184,120,.28),transparent_60%)]" />
      <div className="absolute inset-0 overflow-hidden" aria-hidden>
        {dust.map((p, i) => <span key={i} className="dust" style={{ left: `${p.l}%`, width: p.s, height: p.s, animationDuration: `${p.d}s`, animationDelay: `${p.de}s` }} />)}
      </div>
      <div className="absolute top-16 inset-x-0 flex justify-between px-4 sm:px-8 rise" style={d(0.2)}>
        <img src={LOGOS.school} alt="Logo Trường THPT Nguyễn Thái Bình" className="h-14 sm:h-20 w-auto object-contain" onError={e => (e.currentTarget.style.display = 'none')} />
        <img src={LOGOS.youth} alt="Logo Đoàn TNCS Hồ Chí Minh" className="h-14 sm:h-20 w-auto object-contain" onError={e => (e.currentTarget.style.display = 'none')} />
      </div>
      <div className="relative z-10 h-full flex flex-col items-center justify-center px-5">
        <p className="font-ui text-[11px] sm:text-sm tracking-[.4em] text-gold rise" style={d(0.6)}>TRÂN TRỌNG GIỚI THIỆU</p>
        <h1 className="font-display font-black text-[clamp(2.4rem,11vw,7rem)] leading-[1.02] mt-4 shine rise" style={d(1)}>TRI ÂN THẦY CÔ</h1>
        <h2 className="font-display font-bold text-[clamp(1.5rem,6vw,3.5rem)] tracking-[.3em] text-cream mt-2 rise" style={d(1.4)}>CLASS 10C4</h2>
        <p className="font-quote italic text-[clamp(1.1rem,3.4vw,1.8rem)] text-sand mt-6 max-w-xl rise" style={d(1.9)}>“Người ươm mầm xanh – Người chắp cánh những ước mơ.”</p>
        <p className="font-ui text-[11px] sm:text-xs tracking-[.3em] text-gold/90 mt-5 rise" style={d(2.2)}>20.11 | VIETNAMESE TEACHERS’ DAY</p>
        <div className="flex flex-col sm:flex-row gap-3 mt-9 rise" style={d(2.6)}>
          <button className="btn-gold" onClick={() => go('gallery')}>KHÁM PHÁ 10C4</button>
          <button className="btn-ghost" onClick={() => go('wishes')}>GỬI LỜI CHÚC</button>
        </div>
      </div>
      <ChevronDown className="absolute bottom-5 left-1/2 -translate-x-1/2 text-gold animate-bounce" aria-hidden />
    </section>
  )
}
