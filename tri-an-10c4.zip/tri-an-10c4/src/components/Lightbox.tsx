import { useEffect, useRef } from 'react'
import { ChevronLeft, ChevronRight, X } from 'lucide-react'
import { PHOTOS } from '../data'

export default function Lightbox({ index, onChange, onClose }: { index: number; onChange: (i: number) => void; onClose: () => void }) {
  const n = PHOTOS.length, x0 = useRef(0)
  const prev = () => onChange((index - 1 + n) % n), next = () => onChange((index + 1) % n)
  useEffect(() => {
    const k = (e: KeyboardEvent) => { if (e.key === 'Escape') onClose(); if (e.key === 'ArrowLeft') prev(); if (e.key === 'ArrowRight') next() }
    window.addEventListener('keydown', k); document.body.style.overflow = 'hidden'
    return () => { window.removeEventListener('keydown', k); document.body.style.overflow = '' }
  })
  return (
    <div className="fixed inset-0 z-[100] bg-ink/95 flex items-center justify-center" role="dialog" aria-modal="true"
      onTouchStart={e => (x0.current = e.touches[0].clientX)}
      onTouchEnd={e => { const dx = e.changedTouches[0].clientX - x0.current; if (Math.abs(dx) > 50) dx > 0 ? prev() : next() }}>
      <img src={PHOTOS[index].src} alt={PHOTOS[index].alt} className="max-h-[88vh] max-w-[94vw] object-contain rounded-lg" />
      <button onClick={onClose} aria-label="Đóng" className="absolute top-4 right-4 p-3 text-cream"><X /></button>
      <button onClick={prev} aria-label="Ảnh trước" className="absolute left-2 p-3 text-gold"><ChevronLeft size={36} /></button>
      <button onClick={next} aria-label="Ảnh sau" className="absolute right-2 p-3 text-gold"><ChevronRight size={36} /></button>
      <p className="absolute bottom-4 font-ui text-xs tracking-widest text-cream/80">{index + 1} / {n}</p>
    </div>
  )
}
