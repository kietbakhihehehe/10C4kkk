import { useEffect, useState } from 'react'
import { ChevronLeft, ChevronRight, Pause, Play, X } from 'lucide-react'
import { PHOTOS } from '../data'

export default function Slideshow({ onClose }: { onClose: () => void }) {
  const n = PHOTOS.length
  const [i, setI] = useState(0)
  const [playing, setPlaying] = useState(true)
  useEffect(() => {
    if (!playing) return
    const t = setInterval(() => setI(v => (v + 1) % n), 4000)
    return () => clearInterval(t)
  }, [playing, n, i])
  useEffect(() => {
    const k = (e: KeyboardEvent) => e.key === 'Escape' && onClose()
    window.addEventListener('keydown', k); document.body.style.overflow = 'hidden'
    return () => { window.removeEventListener('keydown', k); document.body.style.overflow = '' }
  }, [onClose])
  return (
    <div className="fixed inset-0 z-[100] bg-ink" role="dialog" aria-modal="true">
      {PHOTOS.map((p, k) => (
        <img key={p.src} src={p.src} alt={p.alt} className="absolute inset-0 w-full h-full object-contain transition-opacity duration-[1400ms]" style={{ opacity: k === i ? 1 : 0 }} />
      ))}
      <button onClick={onClose} aria-label="Đóng" className="absolute top-4 right-4 p-3 text-cream"><X /></button>
      <div className="absolute bottom-6 inset-x-0 flex items-center justify-center gap-5 text-gold">
        <button onClick={() => setI((i - 1 + n) % n)} aria-label="Ảnh trước"><ChevronLeft size={30} /></button>
        <button onClick={() => setPlaying(p => !p)} aria-label={playing ? 'Tạm dừng' : 'Phát'} className="glass rounded-full p-3">{playing ? <Pause /> : <Play />}</button>
        <button onClick={() => setI((i + 1) % n)} aria-label="Ảnh sau"><ChevronRight size={30} /></button>
        <span className="font-ui text-xs tracking-widest text-cream">{i + 1} / {n}</span>
      </div>
    </div>
  )
}
