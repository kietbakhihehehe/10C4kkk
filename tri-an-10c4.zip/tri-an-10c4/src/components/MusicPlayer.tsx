import { Disc3, Pause, Play, Volume2, VolumeX } from 'lucide-react'
import { useAudio } from '../hooks/useAudio'

const mmss = (s: number) => (isFinite(s) ? `${Math.floor(s / 60)}:${String(Math.floor(s % 60)).padStart(2, '0')}` : '0:00')

export default function MusicPlayer() {
  const a = useAudio('/music/nguoi-uom-mam-xanh.mp3')
  return (
    <div className="fixed z-40 right-3 glass rounded-2xl p-3 w-[15.5rem] shadow-[0_0_30px_rgba(214,184,120,.25)]" style={{ bottom: 'calc(env(safe-area-inset-bottom) + .75rem)' }}>
      <div className="flex items-center gap-3">
        <Disc3 className={`text-gold shrink-0 ${a.playing ? 'spin-disc' : ''}`} size={38} aria-hidden />
        <div className="min-w-0 flex-1">
          <p className="font-ui text-xs font-semibold text-cream truncate">Người Ươm Mầm Xanh</p>
          <div className="flex items-end gap-[3px] h-4 mt-1" aria-hidden>
            {[0, .2, .45, .1, .3].map((d, i) => <span key={i} className="bar" style={{ animationDelay: `${d}s`, animationPlayState: a.playing ? 'running' : 'paused', height: a.playing ? undefined : 3 }} />)}
          </div>
        </div>
        <button onClick={a.toggle} aria-label={a.playing ? 'Tạm dừng' : 'Phát nhạc'} className="rounded-full bg-gold text-ink p-2 transition-transform active:scale-90">
          {a.playing ? <Pause size={16} /> : <Play size={16} />}
        </button>
      </div>
      {a.error ? <p className="font-ui text-[11px] text-red-300 mt-2">Chưa có file nhạc. Thêm public/music/nguoi-uom-mam-xanh.mp3</p> : (
        <>
          <input type="range" min={0} max={a.duration || 0} step={1} value={a.time} onChange={e => a.seek(+e.target.value)} className="w-full mt-2 accent-[#D6B878]" aria-label="Tiến trình" />
          <div className="flex justify-between font-ui text-[10px] text-cream/70"><span>{mmss(a.time)}</span><span>{mmss(a.duration)}</span></div>
        </>
      )}
      <div className="flex items-center gap-2 mt-1">
        <button onClick={a.toggleMute} aria-label="Tắt tiếng" className="text-gold">{a.muted || a.volume === 0 ? <VolumeX size={16} /> : <Volume2 size={16} />}</button>
        <input type="range" min={0} max={1} step={0.05} value={a.muted ? 0 : a.volume} onChange={e => a.setVolume(+e.target.value)} className="flex-1 accent-[#D6B878]" aria-label="Âm lượng" />
      </div>
    </div>
  )
}
