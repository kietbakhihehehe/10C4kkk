import { Heart } from 'lucide-react'
import type { Wish } from '../hooks/useWishes'

interface Props { wishes: Wish[]; total: number; loading: boolean; error: string | null; hasMore: boolean; onMore: () => void }
const fmt = (s: string) => new Date(s).toLocaleString('vi-VN', { hour: '2-digit', minute: '2-digit', day: '2-digit', month: '2-digit', year: 'numeric' })

export default function WishWall({ wishes, total, loading, error, hasMore, onMore }: Props) {
  return (
    <div className="max-w-6xl mx-auto mt-16">
      <h3 className="font-display font-bold text-2xl sm:text-3xl text-gold text-center">NHỮNG LỜI CHÚC ĐƯỢC GỬI ĐẾN THẦY CÔ</h3>
      <p className="text-center font-ui text-sm text-cream/80 mt-2">{total} lời chúc</p>
      {error && <p className="text-center text-red-300 mt-6">{error}</p>}
      {!error && !loading && wishes.length === 0 && <p className="text-center text-sand mt-8">Chưa có lời chúc nào. Hãy là người đầu tiên gửi đến thầy cô.</p>}
      <div className="columns-1 sm:columns-2 lg:columns-3 gap-4 mt-8">
        {wishes.map(w => (
          <article key={w.id} className="pop letter break-inside-avoid mb-4 rounded-xl border border-gold/50 p-5 text-ink shadow-lg transition-transform hover:-translate-y-1 hover:rotate-[.4deg]">
            <Heart size={18} className="text-red-500" fill="currentColor" />
            <p className="font-body mt-2 whitespace-pre-wrap break-words">{w.message}</p>
            <footer className="mt-4 pt-3 border-t border-gold/50 font-ui text-xs">
              <strong className="text-moss">{w.sender_name}</strong>{w.class_name ? ` – ${w.class_name}` : ''}
              <div className="text-ink/55 mt-0.5">{fmt(w.created_at)}</div>
            </footer>
          </article>
        ))}
      </div>
      {loading && <p className="text-center text-sand mt-6">Đang tải lời chúc...</p>}
      {hasMore && !loading && <div className="text-center mt-6"><button className="btn-ghost" onClick={onMore}>TẢI THÊM</button></div>}
    </div>
  )
}
