import { useState } from 'react'
import { Heart } from 'lucide-react'

interface Props { onSend: (name: string, cls: string, msg: string) => Promise<string | null> }

export default function WishForm({ onSend }: Props) {
  const [name, setName] = useState(''); const [cls, setCls] = useState(''); const [msg, setMsg] = useState(''); const [trap, setTrap] = useState('')
  const [busy, setBusy] = useState(false); const [status, setStatus] = useState<{ ok: boolean; text: string } | null>(null)
  const [hearts, setHearts] = useState<number[]>([])

  const submit = async () => {
    if (trap) return
    if (!name.trim()) return setStatus({ ok: false, text: 'Vui lòng nhập tên của bạn.' })
    if (!msg.trim()) return setStatus({ ok: false, text: 'Vui lòng viết lời chúc trước khi gửi.' })
    const last = Number(localStorage.getItem('wish-last') || 0)
    if (Date.now() - last < 30000) return setStatus({ ok: false, text: 'Bạn vừa gửi lời chúc, hãy đợi ít giây rồi gửi tiếp.' })
    setBusy(true)
    const err = await onSend(name, cls, msg)
    setBusy(false)
    if (err) return setStatus({ ok: false, text: err })
    localStorage.setItem('wish-last', String(Date.now()))
    setName(''); setCls(''); setMsg('')
    setStatus({ ok: true, text: 'Lời chúc của bạn đã được gửi đến thầy cô. Cảm ơn bạn!' })
    const ids = Array.from({ length: 7 }, (_, i) => Date.now() + i); setHearts(ids); setTimeout(() => setHearts([]), 2000)
  }
  const field = 'w-full rounded-lg bg-white/70 border border-gold/50 px-4 py-3 text-ink placeholder:text-ink/45 font-body focus:bg-white'
  return (
    <div className="letter rounded-2xl border border-gold/60 shadow-2xl p-5 sm:p-8 text-ink max-w-2xl mx-auto">
      <div className="grid sm:grid-cols-2 gap-3">
        <input className={field} placeholder="Tên của bạn..." maxLength={60} value={name} onChange={e => setName(e.target.value)} aria-label="Tên của bạn" />
        <input className={field} placeholder="Lớp của bạn..." maxLength={60} value={cls} onChange={e => setCls(e.target.value)} aria-label="Lớp của bạn" />
      </div>
      <input className="hidden" tabIndex={-1} autoComplete="off" value={trap} onChange={e => setTrap(e.target.value)} aria-hidden />
      <textarea className={`${field} mt-3 h-36 resize-none`} placeholder="Viết lời chúc chân thành của bạn tại đây..." maxLength={600} value={msg} onChange={e => setMsg(e.target.value)} aria-label="Lời chúc" />
      <div className="flex items-center justify-between mt-1 font-ui text-xs text-ink/60"><span>{msg.length}/600</span></div>
      {status && <p role="status" className={`mt-3 text-sm font-medium ${status.ok ? 'text-pine' : 'text-red-700'}`}>{status.text}</p>}
      <button className="btn-gold mt-4 w-full sm:w-auto inline-flex items-center justify-center gap-2 disabled:opacity-60" disabled={busy} onClick={submit}>
        {busy ? 'ĐANG GỬI...' : <>GỬI LỜI CHÚC <Heart size={16} fill="currentColor" /></>}
      </button>
      {hearts.map((h, i) => <Heart key={h} className="heart-fly text-red-500" fill="currentColor" style={{ left: `${40 + i * 4}%`, animationDelay: `${i * 0.1}s` }} />)}
    </div>
  )
}
