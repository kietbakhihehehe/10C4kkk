import { useEffect, useRef, useState } from 'react'
import { Play } from 'lucide-react'
import { PHOTOS } from '../data'
import Lightbox from './Lightbox'
import Slideshow from './Slideshow'

export default function Gallery() {
  const [open, setOpen] = useState<number | null>(null)
  const [show, setShow] = useState(false)
  const root = useRef<HTMLElement>(null)
  useEffect(() => {
    const io = new IntersectionObserver(es => es.forEach(e => { if (e.isIntersecting) { e.target.classList.add('in'); io.unobserve(e.target) } }), { threshold: 0.12 })
    root.current?.querySelectorAll('.reveal').forEach(el => io.observe(el))
    return () => io.disconnect()
  }, [])
  return (
    <section id="gallery" ref={root} className="bg-moss px-4 py-20 sm:py-28">
      <div className="max-w-6xl mx-auto">
        <div className="text-center reveal">
          <h2 className="font-display font-bold text-3xl sm:text-5xl text-gold">THANH XUÂN MANG TÊN 10C4</h2>
          <p className="font-quote italic text-xl sm:text-2xl text-sand mt-4 max-w-2xl mx-auto">“Những khoảnh khắc bình dị, những nụ cười thân quen và những kỷ niệm không thể nào quên.”</p>
          <button className="btn-gold mt-7 inline-flex items-center gap-2" onClick={() => setShow(true)}><Play size={16} /> XEM SLIDESHOW</button>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-4 auto-rows-[38vw] md:auto-rows-[18rem] gap-3 mt-12">
          {PHOTOS.map((p, i) => (
            <button key={p.src} onClick={() => setOpen(i)} style={{ transitionDelay: `${i * 90}ms` }}
              className={`reveal group relative overflow-hidden rounded-2xl border-2 border-gold/40 bg-pine ${i === 0 ? 'col-span-2 row-span-2' : ''}`}>
              <img src={p.src} alt={p.alt} loading="lazy" className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" />
              <span className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity bg-gradient-to-t from-gold/35 to-transparent" />
            </button>
          ))}
        </div>
      </div>
      {open !== null && <Lightbox index={open} onChange={setOpen} onClose={() => setOpen(null)} />}
      {show && <Slideshow onClose={() => setShow(false)} />}
    </section>
  )
}
