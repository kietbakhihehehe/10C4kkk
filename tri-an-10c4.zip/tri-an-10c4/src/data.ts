// Đặt ảnh vào public/images/ rồi thêm tên file vào đây. Ảnh đầu tiên là ảnh nền Hero và ảnh lớn của Gallery.
export const PHOTOS = [
  { src: '/images/class-10c4-01.jpeg', alt: 'Tập thể lớp 10C4 cùng thầy cô' },
  { src: '/images/class-10c4-02.jpeg', alt: 'Lớp 10C4 tạo dáng trái tim' },
  { src: '/images/class-10c4-03.jpeg', alt: 'Tập thể 10C4 trong lớp học' },
  { src: '/images/class-10c4-04.jpeg', alt: 'Những khoảnh khắc vui nhộn của 10C4' }
]
export const LOGOS = { school: '/images/school-logo.png', youth: '/images/youth-logo.png' }
