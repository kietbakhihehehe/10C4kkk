import { useCallback, useEffect, useState } from 'react'
import { supabase } from '../lib/supabase'

export interface Wish { id: number; sender_name: string; class_name: string | null; message: string; created_at: string }
const PAGE = 12

export function useWishes() {
  const [wishes, setWishes] = useState<Wish[]>([])
  const [total, setTotal] = useState(0)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  const load = useCallback(async (from: number) => {
    if (!supabase) { setError('Chưa cấu hình Supabase. Xem README để thiết lập.'); setLoading(false); return }
    setLoading(true)
    const { data, count, error } = await supabase.from('wishes').select('*', { count: 'exact' })
      .order('created_at', { ascending: false }).range(from, from + PAGE - 1)
    if (error) setError('Không tải được lời chúc. Vui lòng tải lại trang.')
    else { setError(null); setTotal(count ?? 0); setWishes(p => from === 0 ? data as Wish[] : [...p, ...(data as Wish[])]) }
    setLoading(false)
  }, [])

  useEffect(() => { load(0) }, [load])

  const send = async (name: string, cls: string, message: string): Promise<string | null> => {
    if (!supabase) return 'Chưa cấu hình Supabase.'
    const { data, error } = await supabase.from('wishes')
      .insert({ sender_name: name.trim(), class_name: cls.trim() || null, message: message.trim() }).select().single()
    if (error) return error.message.includes('Quá nhiều') ? error.message : 'Gửi không thành công, vui lòng thử lại.'
    setWishes(p => [data as Wish, ...p]); setTotal(t => t + 1)
    return null
  }
  return { wishes, total, loading, error, send, loadMore: () => load(wishes.length), hasMore: wishes.length < total }
}
