import { useEffect, useRef, useState } from 'react'

export function useAudio(src: string) {
  const ref = useRef<HTMLAudioElement | null>(null)
  const [playing, setPlaying] = useState(false)
  const [time, setTime] = useState(0)
  const [duration, setDuration] = useState(0)
  const [volume, setVolumeState] = useState(0.7)
  const [muted, setMuted] = useState(false)
  const [error, setError] = useState(false)

  useEffect(() => {
    const a = new Audio(); a.preload = 'metadata'; a.loop = true; a.src = src; a.volume = 0.7
    a.onloadedmetadata = () => setDuration(a.duration)
    a.ontimeupdate = () => setTime(a.currentTime)
    a.onplay = () => setPlaying(true); a.onpause = () => setPlaying(false)
    a.onerror = () => { setError(true); setPlaying(false) }
    ref.current = a
    return () => { a.pause(); a.src = '' }
  }, [src])

  const toggle = async () => {
    const a = ref.current; if (!a) return
    if (a.paused) { try { await a.play(); setError(false) } catch { setError(true) } } else a.pause()
  }
  const seek = (t: number) => { if (ref.current) ref.current.currentTime = t }
  const setVolume = (v: number) => { setVolumeState(v); if (ref.current) { ref.current.volume = v; ref.current.muted = v === 0; setMuted(v === 0) } }
  const toggleMute = () => { const a = ref.current; if (!a) return; a.muted = !a.muted; setMuted(a.muted) }
  return { playing, time, duration, volume, muted, error, toggle, seek, setVolume, toggleMute }
}
