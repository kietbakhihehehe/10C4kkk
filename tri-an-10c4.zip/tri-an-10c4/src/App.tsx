import { useEffect, useRef } from 'react'
import Navbar from './components/Navbar'
import Hero from './components/Hero'
import Gallery from './components/Gallery'
import WishForm from './components/WishForm'
import WishWall from './components/WishWall'
import MusicPlayer from './components/MusicPlayer'
import { useWishes } from './hooks/useWishes'

export default function App() {
  const w = useWishes()
  const sec = useRef<HTMLElement>(null)
  useEffect(() => {
    const io = new IntersectionObserver(es => es.forEach(e => e.isIntersecting && e.target.classList.add('in')), { threshold: 0.1 })
    sec.current?.querySelectorAll('.reveal').forEach(el => io.observe(el)); return () => io.disconnect()
  }, [])
  return (
    <>
      <Navbar />
      <main>
        <Hero />
        <Gallery />
        <section id="wishes" ref={sec} className="bg-gradient-to-b from-moss to-ink px-4 pt-20 sm:pt-28 pb-32">
          <div className="max-w-2xl mx-auto text-center reveal mb-10">
            <h2 className="font-display font-bold text-3xl sm:text-5xl text-gold">GỬI NGÀN LỜI YÊU THƯƠNG</h2>
            <p className="font-quote italic text-xl sm:text-2xl text-sand mt-4">“Bạn có điều gì muốn gửi đến thầy cô trong ngày đặc biệt này không?”</p>
            <p className="mt-4 text-cream/85 leading-relaxed">Mỗi lời chúc là một món quà tinh thần. Hãy để lại những tình cảm chân thành nhất dành cho những người đã tận tâm dạy dỗ chúng ta.</p>
          </div>
          <WishForm onSend={w.send} />
          <WishWall wishes={w.wishes} total={w.total} loading={w.loading} error={w.error} hasMore={w.hasMore} onMore={w.loadMore} />
        </section>
      </main>
      <MusicPlayer />
    </>
  )
}
