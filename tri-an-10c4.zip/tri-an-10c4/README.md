# Tri Ân Thầy Cô – Class 10C4

React + Vite + TypeScript + Tailwind + Supabase. Chỉ 3 khu vực: Hero, Gallery, Lời chúc.

## 1. Thêm tài nguyên (bắt buộc, chưa có sẵn trong gói này)
- `public/images/class-10c4-01.jpeg` … `-04.jpeg` – ảnh gốc của lớp (ảnh 01 là nền Hero + ảnh lớn Gallery).
  Thêm ảnh khác: copy vào `public/images/` rồi thêm vào mảng `PHOTOS` trong `src/data.ts`.
- `public/images/school-logo.png`, `public/images/youth-logo.png` – 2 logo gốc.
- `public/music/nguoi-uom-mam-xanh.mp3` – file nhạc bạn có quyền sử dụng. Thiếu file, player sẽ báo lỗi rõ ràng.

## 2. Thiết lập Supabase (lưu lời chúc thật)
1. Tạo project tại supabase.com.
2. SQL Editor → dán toàn bộ `supabase.sql` → Run (tạo bảng `wishes`, bật RLS, giới hạn độ dài, chống spam 5 lời/phút).
3. Project Settings → API → copy URL và `anon public key`.
4. `cp .env.example .env` rồi điền 2 giá trị. Tuyệt đối không dùng `service_role` key.

## 3. Chạy
```
npm install
npm run dev      # http://localhost:5173
npm run build
```

## 4. Deploy (Vercel hoặc Netlify)
Đẩy code lên GitHub → import vào Vercel/Netlify → Build `npm run build`, Output `dist`
→ thêm 2 biến môi trường `VITE_SUPABASE_URL`, `VITE_SUPABASE_ANON_KEY` → Deploy.
