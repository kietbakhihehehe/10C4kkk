export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: { moss: '#183C35', pine: '#244C40', gold: '#D6B878', cream: '#FFF9EF', sand: '#EEE5D6', ink: '#101412' },
      fontFamily: {
        display: ['"Playfair Display"', 'serif'],
        quote: ['"Cormorant Garamond"', 'serif'],
        body: ['"Be Vietnam Pro"', 'sans-serif'],
        ui: ['Inter', 'sans-serif']
      }
    }
  }
}
